package ie.metlife.utils

import java.net.URL

import org.apache.commons.codec.binary.Base64
import org.apache.spark.sql.functions.udf
import sun.security.util.Password
import scalaj.http._
import scala.io.Source


object Authentication {

  val BASIC = "Basic";
  val AUTHORIZATION = "Authorization";

  def encodeCreds(username: String, password: String): String = {
    new String(Base64.encodeBase64String((username + ":" + password).getBytes));
  };

  def getHeader(username: String, password: String): String =
    BASIC + " " + encodeCreds(username, password);

  def getResponse(url: String,userName:String,password: String): String = {
    //val connection = new URL(url).openConnection
    var body = ""
    //connection.setRequestProperty(Authentication.AUTHORIZATION, Authentication.getHeader(userName,password));
    //val response = Source.fromInputStream(connection.getInputStream);
    println(url)
    try{
      println(url)
    val response: HttpResponse[String] = Http(url).header("Authorization",getHeader(userName,password))
      .options(HttpOptions.allowUnsafeSSL).options(HttpOptions.connTimeout(2000000000)).options(HttpOptions.readTimeout(2000000000)).asString
    body = response.body

      println(body)
    body
  }
  catch{
    case e: Exception =>
      print(e.printStackTrace());print(url);url

  }
  }
  val callForResponse = udf((x:String,u:String,p:String) => getResponse(x,u,p))
}
